# CRM Imobiliário — Engenharia reversa (referência: crm.basimob.app)

Capturado em 23/10/2026. Prints em `screens/` (viewport 980×569, escala 0,5). Nenhum cadastro foi salvo.

## 1. Stack e design system detectados
- **Framework:** Next.js (Turbopack) + React, componentes **shadcn/ui + Radix**, Tailwind CSS.
- **Fonte:** Inter (corpo 16px). Fundo `#fff`, texto `hsl(222.2 84% 4.9%)`.
- **Tokens (HSL, padrão shadcn):** `--primary/--ring/--brand: 205 90% 60%` (azul claro), `--brand-deep: 206 66% 50%`, `--brand-sky: 204 91% 70%`, `--secondary/--muted/--accent: 210 40% 96.1%`, `--muted-foreground: 215.4 16.3% 46.9%`, `--destructive: 0 84.2% 60.2%`, `--border: 214.3 31.8% 91.4%`, `--input: 214 23% 87%`, `--radius: .5rem`. Tema Claro/Escuro/Sistema.
- **Padrões de UI:** cards com borda leve e cantos arredondados; estados vazios centralizados (ícone em círculo + título + texto + link "+ Cadastrar…"); botão primário azul "+ Novo X" no canto superior direito; busca + Filtros + toggle Cards/Lista ou Kanban/Lista; selects com `<select>` nativo oculto por trás de botão Radix; inputs com label flutuante dentro da borda.

## 2. Layout global
- **Sidebar** (recolhível – "Recolher"): logo + nome da empresa, sino de notificações, card do usuário (avatar inicial, nome, e-mail → `/perfil`), campo "Pergunte à Isa…" (assistente IA), menu "PRINCIPAL", rodapé com Configurações, Recolher, Sair (vermelho).
- **Menu:** Início, Imóveis, Empreendimentos, Leads, Proprietários, Vendas, Aluguéis, Análise de Proponentes, Vistorias, Financiamentos, Tarefas, Agenda, Atendimento, Relatórios, Atividades, Marketing, Meu Site, Blog, Financeiro, Isa (IA), Automações, Integrações, Empresa, DIMOB, Equipe, Configurações.
- **Botão global "+ Novo"** (dashboard): Cadastrar Imóvel · Cadastrar Empreendimento · Novo Lead · Nova Simulação · Agendar · Nova Tarefa · Recado para a equipe.

## 3. Telas

| Rota | Tela | Elementos | Ação "Novo" → destino |
|---|---|---|---|
| `/dashboard` | Início | Saudação + data + empresa; Personalizar; busca global; onboarding "Sua conta em 3 passos" (Trazer imóveis/XML, Conectar WhatsApp, Testar Isa); card tour demo; KPIs (Imóveis, Empreendimentos, Leads, Financiamentos, Vendas) | menu global |
| `/imoveis` | Imóveis | Rascunhos, busca (código/ref/título/rua/bairro), Filtros, Cards/Lista | `/imoveis/novo` |
| `/empreendimentos` | Empreendimentos | Configurar reservas, Rascunhos, busca, Filtros, Cards/Lista | `/empreendimentos/novo` |
| `/leads` | Leads (Kanban) | Colunas: Novos, Contatados, Qualificados, Negociando, Convertidos, Perdidos; Adicionar coluna; Kanban/Lista; Filtros | `/leads/novo` |
| `/proprietarios` | Proprietários | Busca (nome/CPF/celular/e-mail), filtros Locação, Cadastro, Ordenar por | `/proprietarios/novo` |
| `/vendas` | Vendas (pipeline) | KPIs Em aberto/Finalizadas/Desistentes; Pós-Venda; filtros Ativos/Responsável; colunas Interesse, Em Análise, Documentação, Financiamento, Pagamento, Finalizada, Desistente | `/vendas/nova` |
| `/alugueis` | Aluguéis | Configurações; KPIs Contratos ativos, Receita mensal, A receber, Inadimplência, A repassar; "Precisa de atenção": Contratos/Seguros vencendo, Pagamentos atrasados, Repasses a fazer, Ocorrências abertas; gráfico Recebimentos 6 meses | `/alugueis/contratos/novo` |
| `/proponentes` | Análise de Proponentes | Estado vazio + lista do que é verificado (identidade, renda, emprego, cobrança, processos, dívida ativa, participação societária, tendência de inadimplência) | `/proponentes/nova` |
| `/vistorias` | Vistorias | Busca, Tipo, Responsável, Ordenar; chips Todas/Capturando/Analisando/Em revisão/Concluídas | modal |
| `/financiamentos` | Financiamentos | KPIs Simulações ativas, Arquivadas, Propostas em andamento, Aprovadas; atalhos Simulações / Propostas; Últimas simulações/propostas | `/financiamentos/simulacoes/nova` (também `/financiamentos/propostas`) |
| `/tarefas` | Tarefas (Quadro) | Colunas A fazer, Em andamento…; Adicionar coluna; Quadro/Lista; Filtros | modal |
| `/agenda` | Agenda | Navegação de mês, Roteiro de visitas, Chaves fora, Filtros, Mês/Semana/Dia/Lista, painel "Hoje" com "Adicionar neste dia" | modal |
| `/atendimento` | Inbox de atendimento | Estado "não configurado" → Configurar Integração; link conversas da Isa | — |
| `/relatorios` | Relatórios | Exportar; Este mês/Trimestre/Este ano; Filtros avançados (Responsável, Origem, Tipo de imóvel, Empreendimento, datas); KPIs; abas Visão Geral, Funil, Comissões, Aluguéis, Tempo, Comparativo, Origem, Performance, Imóveis, Atendimento, Leads, Vendas; gráficos Evolução mensal, Funil de conversão | — |
| `/atividades` | Atividades | Busca, Tipo, Apenas minhas, Usuário | Nova Atividade (não capturado o formulário) |
| `/marketing` | Marketing | Abas Visão geral / Link da bio / Biblioteca; "Criar uma arte" (chips Contato, Dica, Frase, Data, Depoimento…); checklist "Comece por aqui" | `/marketing/criativos` (Estúdio) |
| `/meu-site` | Meu Site | redireciona p/ `/meu-site/setup` (wizard) | — |
| `/blog` | Blog | Bloqueado até configurar site → "Configurar Meu Site" | — |
| `/financeiro` | Financeiro | Importar, Relatório; Mês/Ano/Período; seletor de mês; toggle "Receita do CRM"; abas Visão geral/Lançamentos/Mês a mês/Categorias; KPIs Receitas, Despesas, Resultado, Saldo em caixa; gráficos mensal e por categoria | — |
| `/isa` | Isa (IA) | KPIs (conversas, mensagens, leads qualificados, encaminhados, tempo de resposta, taxa de escalação); Inteligência dos leads; Procuras sem imóvel; config: ativar, nome, tom de voz, fora do horário, módulos (vendas/locação, financiamento, aluguel), retomar conversas, base de conhecimento, diferenciais, plano | — |
| `/automacoes` | Automações | Regras automáticas; Modelos prontos (Roleta de leads, Tarefa de primeiro contato, Aniversário, Retorno após visita…); Integrar com outros sistemas | `/automacoes/nova` |
| `/integracoes` | Integrações | Chips: Todas 37, Comunicação 2, Captação 1, Portais 25, Recebimentos 7, Produtividade 2; cards (WhatsApp, Messenger/Instagram, Meta Lead Ads, ZAP, OLX, Viva Real, ImovelWeb, QuintoAndar, Loft, Mercado Livre…) com "Configurar integração" | `/integracoes/whatsapp/conectar` |
| `/empresa` | Minha Empresa | Identificação (logo, nome fantasia, razão social, CNPJ/CPF, CRECI), Contato, Endereço, Preferências (fuso, comissão padrão), Info da conta, Estatísticas; Salvar | — |
| `/dimob` | DIMOB | Ano-calendário 2023–2026; Dados fiscais (CNPJ, razão social, cód. município TOM, UF); Como entregar; R04 Intermediação de venda; R02 Locação administrada; Baixar .txt, Relatório PDF, Marcar como entregue | — |
| `/equipe` | Equipe e acessos | Recados, Gerenciar equipes; busca + Perfil de acesso; card do membro (contatos/imóveis/propostas, último acesso) | `/equipe/novo` |
| `/configuracoes` | Configurações | Conta (Meu perfil, Alterar senha, Gerenciar plano, Indique); Notificações Push e E-mail (switches por evento); Aparência Claro/Escuro/Sistema; Aplicativo (PWA Instalar); Novidades | — |
| `/notificacoes` | Notificações | Todas/Não lidas; Preferências | — |
| `/perfil` | Meu Perfil | Upload avatar; e-mail, perfil, membro desde; nome, celular; Acesso aos módulos; Alterar senha (atual/nova/confirmar) | — |

## 4. Formulários de criação (campos; * = obrigatório)

**Imóvel** `/imoveis/novo` — wizard 4 passos: 1 Essencial (fotos, tipo, valor, local) · 2 Detalhes (medidas, custos, descrição) · 3 Divulgação (site, portais, mídia) · 4 Interno (donos, captador, referências). Passo 1: Fotos (até 35, JPG/PNG/WebP/HEIC ≤25 MB) + toggle Marca d'água; Tipo de imóvel*; Novo/Usado; Finalidade: Venda | Locação mensal; Valor de venda* + "A negociar"; CEP*, UF*, Cidade (depende UF), Logradouro, Número + "Sem número", Complemento, Bairro; Título do anúncio*. Rodapé: Continuar · Salvar e publicar · Salvar como rascunho.

**Empreendimento** `/empreendimentos/novo` — mesmos 4 passos (Detalhes: comodidades, unidades; Divulgação: site, vídeo, tour 3D; Interno: comissão, captador). Passo 1: Fotos; Nome*; Construtora; CNPJ construtora; Tipo* (Residencial Vertical, Residencial Horizontal, Loteamento, Comercial, Misto); Status da obra* (Pré-Lançamento, Lançamento, Em Obras, Pronto, Entregue); Data de lançamento; Previsão de entrega; Total de unidades; Valor mín./máx.; endereço completo.

**Lead** `/leads/novo` — Informações básicas: Nome*, E-mail, Celular*, Instagram, Facebook, CPF/CNPJ (tipo de pessoa automático), RG, Data nasc., Estado civil (Solteiro, Casado, Divorciado, Viúvo, União Estável). Endereço residencial. Profissionais: Profissão, Renda mensal, Nacionalidade. Status* (colunas do kanban), Origem* (Site, Manual, OLX, Facebook, Instagram…), Interesse. Tags (Adicionar). Responsável. Imóvel de interesse (busca + m²). Botões Cancelar · Cadastrar Lead.

**Proprietário** `/proprietarios/novo` — seções colapsáveis: Dados pessoais (nome, CPF/CNPJ, RG, e-mail, celular, nascimento, nacionalidade "Brasileiro(a)", profissão, estado civil); Endereço residencial; Imóveis (vincular); Taxa de administração (vazio = padrão da org; taxa negociada); Dados de pagamento (Pix ou conta, para repasse). Cadastrar proprietário.

**Proposta de venda** `/vendas/nova` — Partes: Cliente/Lead* (busca nome/CPF/CNPJ), Imóvel ou Empreendimento* (busca); Dados: Valor*, Prazo de validade, Simulação vinculada, Responsável (chip); Condições de pagamento, Observações. Cancelar · Criar Proposta.

**Contrato de aluguel** `/alugueis/contratos/novo` — wizard 6 passos: Partes (imóvel*, responsável, vincular locatário*, vincular proprietário) · Seguro (apólice, vigência, quem paga) · Valores (aluguel, encargos, taxas) · Vigência (prazo, vencimento, reajuste) · Garantia (garantia, desconto, multa, juros) · Conferência (agenda de parcelas). Continuar · Cancelar · Salvar rascunho.

**Consulta de proponente** `/proponentes/nova` — wizard 3 passos: Proponentes (Nome, CPF/CNPJ*, + cônjuge/co-proponente/fiador) · Valores (finalidade, imóvel, renda) · Verificações (o que consultar, custo por item). Aviso de cobrança por uso.

**Nova vistoria** (modal) — Tipo (Entrada/Saída…), Vincular a: Contrato de aluguel | Só o imóvel (busca), Data; aviso de cota de laudos IA; Cancelar · Iniciar captura.

**Simulação multi-banco** `/financiamentos/simulacoes/nova` — 2 passos: Cliente (Nome* com busca de lead, CPF, Nascimento*, Renda familiar, switches "já possui imóvel" e "+36 meses FGTS") · Imóvel (localização e características). Próximo: Imóvel.

**Nova tarefa** (modal) — Título*; Prioridade Baixa/Média/Alta/Urgente; Prazo (data+hora, atalhos Amanhã/2 dias/Segunda); Avisos; Checklist; Quem (responsável); Vínculos (Cliente, Imóvel/Empreendimento, Venda, Contrato); Descrição. Criar tarefa.

**Novo compromisso** (modal) — Título*; Tipo Visita/Reunião/Ligação/Outros; Quando (início*/fim* data+hora, Dia inteiro, Repetir: não/diário/semanal/mensal/anual); Avisos; Quem (responsável, participantes); Vínculos; Mensagens ao cliente; Onde (local, endereço, descrição). Criar compromisso.

**Estúdio de arte** `/marketing/criativos` — 3 passos: O que divulgar (Imóvel ou lançamento | Post da imobiliária | Tela em branco) · Qual · Peça e formato.

**Meu Site** `/meu-site/setup` — wizard: Modelo (Clássico, Moderno, Tradicional, Primeiro Imóvel, Balcão, Explorar) · Empresa · Redes sociais · Endereço do site · Finalizar.

**Nova regra** `/automacoes/nova` — escolher "Montar do zero" ou modelo (Roleta de leads, Lead parado sem ninguém pegar, Lead qualificado, Tarefa vencida, Visita sem desfecho…); cada modelo mostra gatilho → ação.

**Novo membro** `/equipe/novo` — Nome*, E-mail*, Celular; acesso: Enviar convite por e-mail | Definir senha; Perfil: Administrador/Corretor/Apoio; Equipes (Criar equipe); Áreas (switches por módulo em grupos Cadastros, Comercial, Locação, Produtividade, Divulgação); O que vê (Toda a imobiliária / Os seus, da equipe e sem responsável…); Contatos e ausência; Resumo do acesso; Comissão (Percentual | Valor fixo). Salvar.

## 5. Entidades sugeridas (Supabase)
organizations, profiles/members (role, permissões por módulo), teams, properties (+ photos, owners), developments (+ units), leads (status, origem, tags), owners, sales_proposals (stage), rental_contracts (+ installments, repasses, ocorrências), applicant_checks, inspections, financing_simulations, financing_proposals, tasks (+ checklist), events (agenda), activities, automations, integrations, finance_entries/categories, notifications, site_config, blog_posts, ai_assistant_config.

## 6. Não capturado
Passos 2+ dos wizards (exigem dados válidos para avançar), formulário "Nova Atividade", conteúdo de listas com dados (conta vazia), modo escuro e telas mobile.
